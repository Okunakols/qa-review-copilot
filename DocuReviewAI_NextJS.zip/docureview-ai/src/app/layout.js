import './globals.css'

export const metadata = {
  title: 'DocuReview AI — Intelligent QA Document Review',
  description: 'AI-powered document review platform for ISO 13485, EU MDR, and FDA 21 CFR compliance.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
