'use client'

import { useState, useRef } from 'react'
import Chrome from '@/components/Chrome'
import Sidebar from '@/components/Sidebar'
import FindingsPanel from '@/components/FindingsPanel'
import { SettingsModal, HistoryModal, ReportModal } from '@/components/modals/Modals'
import SourceModal from '@/components/modals/SourceModal'
import { useReview } from '@/hooks/useReview'
import { ANALYSIS_STEPS } from '@/lib/constants'
import { fmtB, downloadBlob, exportCSV, buildReportText } from '@/lib/utils'

export default function Page() {
  const r = useReview()

  const [modal, setModal]  = useState(null) // 'source' | 'settings' | 'history' | 'report'
  const [reportText, setReportText] = useState('')
  const fileInputRef = useRef()

  // ── Drag & drop ───────────────────────────────────────────────────────────
  const [dragging, setDragging] = useState(false)
  const onDrop = (e) => {
    e.preventDefault(); setDragging(false)
    const f = e.dataTransfer.files[0]
    if (f) r.setFile(f)
  }

  // ── Report modal ──────────────────────────────────────────────────────────
  const openReport = () => {
    const text = buildReportText({
      result: r.result, findings: r.findings, dispositions: r.dispositions,
      reviewId: r.reviewId, cfg: r.cfg, sel: r.sel, metadata: r.metadata,
      fileName: r.mainFile?.name,
    })
    setReportText(text)
    setModal('report')
  }

  const riskClass  = { High: 'rb-H', Medium: 'rb-M', Low: 'rb-L' }
  const readyClass = {
    'Not Ready': 'rbadge-nr', 'Needs Work': 'rbadge-nw',
    'Mostly Ready': 'rbadge-mr', 'Audit Ready': 'rbadge-ar',
  }

  return (
    <>
      {/* Modals */}
      {modal === 'source' && (
        <SourceModal
          onClose={() => setModal(null)}
          onAdd={r.addSource}
        />
      )}
      {modal === 'settings' && (
        <SettingsModal
          cfg={r.cfg}
          onClose={() => setModal(null)}
          onSave={r.saveSettings}
        />
      )}
      {modal === 'history' && (
        <HistoryModal
          history={r.history}
          onClose={() => setModal(null)}
        />
      )}
      {modal === 'report' && (
        <ReportModal
          reportText={reportText}
          onClose={() => setModal(null)}
          onPrint={() => window.print()}
          onCSV={() => exportCSV(r.findings, r.dispositions, r.reviewId)}
        />
      )}

      {/* Chrome */}
      <Chrome
        reviewId={r.reviewId}
        author={r.cfg.author}
        initials={r.cfg.initials}
        onSettings={() => setModal('settings')}
        onHistory={() => setModal('history')}
      />

      <div className="workspace">
        {/* Sidebar */}
        <Sidebar
          sources={r.sources}
          onAdd={() => setModal('source')}
          onToggle={r.toggleSource}
          onDelete={r.deleteSource}
        />

        {/* Main */}
        <div className="main">

          {/* Metadata bar */}
          <div className="meta-bar">
            {[
              { id: 'doc', label: 'Project / Document', placeholder: 'e.g. SBSVP-2025-001', flex: 1 },
              null,
              { id: 'rev', label: 'Revision', placeholder: 'Rev 00', maxWidth: 100 },
              null,
              { id: 'company', label: 'Company', placeholder: 'MedTech Inc.', maxWidth: 130 },
              null,
              { id: 'date', label: 'Date', type: 'date', maxWidth: 130 },
            ].map((field, i) =>
              field === null ? (
                <div key={i} className="meta-divider" />
              ) : (
                <div key={field.id} className="meta-field" style={field.maxWidth ? { maxWidth: field.maxWidth } : {}}>
                  <span className="meta-lbl">{field.label}</span>
                  <input
                    className="meta-inp"
                    type={field.type || 'text'}
                    placeholder={field.placeholder}
                    value={r.metadata[field.id] || ''}
                    onChange={(e) => r.setMetadata((m) => ({ ...m, [field.id]: e.target.value }))}
                  />
                </div>
              )
            )}
          </div>

          {/* API Key */}
          {!r.keyOk ? (
            <ApiKeyStrip onSave={r.saveKey} />
          ) : (
            <div className="ak-strip ok">
              <div className="ak-ico" style={{ background: 'rgba(34,197,94,.15)' }}>✅</div>
              <div className="ak-body">
                <div className="ak-ok-row">
                  <div className="ak-ok-dot" />
                  <span className="ak-ok-txt">API key authenticated</span>
                  <span className="ak-chg" onClick={r.changeKey}>Change</span>
                </div>
                <div className="ak-sub" style={{ marginTop: 3 }}>Ready to analyze documents</div>
              </div>
            </div>
          )}

          {/* Error */}
          {r.error && (
            <div className="err-card">
              <span>⚠</span>
              <span>{r.error}</span>
            </div>
          )}

          {/* Drop zone */}
          <div className="dropcard">
            <div className="dropcard-h">
              <div className={`dch-dot${r.mainFile ? ' active' : ''}`} />
              <span className="dch-title">Primary Document</span>
              <span className="dch-sub">.docx · .pdf · .txt · max 10MB</span>
            </div>
            <div
              className={`dz${r.mainFile ? ' has' : ''}${dragging ? ' over' : ''}`}
              onClick={() => !r.mainFile && fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
            >
              {r.mainFile ? (
                <>
                  <span className="dz-icon">📄</span>
                  <div className="dz-name">{r.mainFile.name}</div>
                  <div className="dz-sub">{fmtB(r.mainFile.size)}</div>
                  <button className="dz-rm" onClick={(e) => { e.stopPropagation(); r.removeFile() }}>
                    Remove
                  </button>
                </>
              ) : (
                <>
                  <span className="dz-icon">📤</span>
                  <div className="dz-title">Drop document here or click to browse</div>
                  <div className="dz-sub">Supports Word, PDF (text-based), and plain text</div>
                </>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".docx,.pdf,.txt"
              style={{ display: 'none' }}
              onChange={(e) => e.target.files[0] && r.setFile(e.target.files[0])}
            />
          </div>

          {/* Config */}
          <ConfigCard sel={r.sel} onSeg={r.setSegment} />

          {/* Status */}
          {r.loading && (
            <div className="status-card">
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ink3)', marginBottom: 10 }}>
                Analysis in progress…
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {ANALYSIS_STEPS.map((s, i) => {
                  const done   = i < r.stepIdx
                  const active = i === r.stepIdx
                  return (
                    <div key={s.id} className={`step-row${active ? ' active' : ''}${done ? ' done' : ''}`}>
                      <div className={`step-icon${active ? ' active' : ''}${done ? ' done' : ''}`}>
                        {done ? '✓' : active ? '●' : i + 1}
                      </div>
                      <span style={{ fontSize: 11 }}>{s.label}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* CTA */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button
              className="btn-review"
              onClick={r.startReview}
              disabled={!r.canStart || r.loading}
            >
              {r.loading ? '⏳  Analyzing…' : '▶   Start AI Review'}
            </button>
            <div className="privacy">
              🔒 Documents are not stored on any server. Content is processed by AI engine for analysis only.
              Output: <strong>FileName_reviewed.docx</strong> — original untouched, comments injected into copy.
            </div>
          </div>

          {/* Results */}
          {r.result && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {/* Summary */}
              <div className="summary-strip">
                <div className="ss-top">
                  <div>
                    <div className="ss-title">Review Complete</div>
                    <div className="ss-id">
                      {r.reviewId} · {new Date().toLocaleString('en-GB')} · {r.mainFile?.name}
                    </div>
                  </div>
                  <div className="ss-badges">
                    <span className={`risk-badge ${riskClass[r.result.overallRisk] || 'rb-M'}`}>
                      {r.result.overallRisk} RISK
                    </span>
                    <span className={`ready-badge ${readyClass[r.result.auditReadiness] || 'rbadge-nw'}`}>
                      {r.result.auditReadiness}
                    </span>
                  </div>
                </div>
                <div className="ss-text">{r.result.summary}</div>
              </div>

              {/* Stats */}
              <div className="stats-row">
                {[
                  ['st0', 'sv0', r.findings.length, 'Total'],
                  ['st1', 'sv1', r.findings.filter(f=>f.severity==='Critical').length, 'Critical'],
                  ['st2', 'sv2', r.findings.filter(f=>f.severity==='Major').length, 'Major'],
                  ['st3', 'sv3', r.findings.filter(f=>f.severity==='Minor').length, 'Minor'],
                  ['st4', 'sv4', r.findings.filter(f=>f.severity==='OBSERVATION').length, 'Observ.'],
                  ['st5', 'sv5', r.findings.filter(f=>f.severity==='OFI').length, 'OFI'],
                ].map(([id, cls, val, label]) => (
                  <div key={id} className="stat">
                    <div className={`stat-v ${cls}`}>{val}</div>
                    <div className="stat-l">{label}</div>
                  </div>
                ))}
              </div>

              {/* Download */}
              {r.reviewedBlob && (
                <div className="dl-banner">
                  <div className="dl-ico">📄</div>
                  <div className="dl-info">
                    <div className="dl-title">{r.outName} ready</div>
                    <div className="dl-sub">
                      All findings injected as Word Comments. Track Changes applied where applicable.
                    </div>
                  </div>
                  <button className="btn-dl" onClick={() => downloadBlob(r.reviewedBlob, r.outName)}>
                    ⬇ Download .docx
                  </button>
                  <button className="btn-report" onClick={openReport}>
                    📊 Export Report
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right panel */}
        <FindingsPanel
          findings={r.findings}
          filtered={r.filtered}
          activeFilter={r.activeFilter}
          onFilter={r.applyFilter}
          dispositions={r.dispositions}
          onDisposition={r.setDisposition}
          onNote={r.setNote}
          hasResults={!!r.result}
          onReset={r.resetReview}
        />
      </div>
    </>
  )
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function ApiKeyStrip({ onSave }) {
  const [val, setVal] = useState('')
  return (
    <div className="ak-strip">
      <div className="ak-ico">🔑</div>
      <div className="ak-body">
        <div className="ak-title">AI Engine API Key Required</div>
        <div className="ak-sub">Enter your API key. Stored in session memory only — never transmitted or logged.</div>
        <div className="ak-row">
          <input
            className="ak-inp"
            type="password"
            placeholder="Enter API key…"
            value={val}
            onChange={(e) => setVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSave(val)}
          />
          <button className="ak-save" onClick={() => onSave(val)}>Authenticate</button>
        </div>
      </div>
    </div>
  )
}

const CONFIG_COLS = [
  {
    id: 'lang', label: 'Language',
    options: [
      { v: 'Turkish', label: '🇹🇷 Turkish' },
      { v: 'English', label: '🇺🇸 English' },
    ],
  },
  {
    id: 'tone', label: 'Comment Tone',
    options: [
      { v: 'Formal',   label: 'Formal / Audit' },
      { v: 'Simple',   label: 'Simple' },
      { v: 'Friendly', label: 'Friendly' },
    ],
  },
  {
    id: 'reg', label: 'Regulatory',
    options: [
      { v: 'ISO13485', label: 'ISO 13485' },
      { v: 'EUMDR',   label: 'EU MDR' },
      { v: 'FDA',     label: 'FDA 21 CFR' },
      { v: 'ALL',     label: 'All Pathways' },
    ],
  },
  {
    id: 'int', label: 'Intensity',
    options: [
      { v: 'Light',    label: 'Light' },
      { v: 'Standard', label: 'Standard' },
      { v: 'Strict',   label: 'Strict / Audit' },
    ],
  },
]

function ConfigCard({ sel, onSeg }) {
  return (
    <div className="config-card">
      <div style={{ padding: '11px 14px', borderBottom: '1px solid var(--fog)' }}>
        <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--ink3)' }}>Review Configuration</span>
      </div>
      <div className="config-grid">
        {CONFIG_COLS.map((col) => (
          <div key={col.id} className="config-col">
            <span className="cfg-lbl">{col.label}</span>
            <div className="segs">
              {col.options.map((opt) => (
                <button
                  key={opt.v}
                  className={`seg${sel[col.id] === opt.v ? ' on' : ''}`}
                  onClick={() => onSeg(col.id, opt.v)}
                >
                  <span className="seg-dot" />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
