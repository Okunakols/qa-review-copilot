'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { LS_KEYS, ANALYSIS_STEPS } from '@/lib/constants'
import { generateReviewId, fmtB } from '@/lib/utils'
import { readFileText } from '@/lib/fileReader'
import { callAI } from '@/lib/api'
import { injectComments } from '@/lib/docx'

function loadLS(key, fallback) {
  if (typeof window === 'undefined') return fallback
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback }
}

export function useReview() {
  // ── Config ────────────────────────────────────────────────────────────────
  const [apiKey,   setApiKey]   = useState('')
  const [keyOk,    setKeyOk]    = useState(false)
  const [cfg,      setCfg]      = useState({ author: '', initials: '', org: '' })
  const [sel,      setSel]      = useState({ lang: 'Turkish', tone: 'Formal', reg: 'ISO13485', int: 'Standard' })

  // ── Document ──────────────────────────────────────────────────────────────
  const [mainFile, setMainFile] = useState(null)
  const [metadata, setMetadata] = useState({ doc: '', rev: '', company: '', date: '' })
  const mainDocxBufRef = useRef(null)

  // ── Sources ───────────────────────────────────────────────────────────────
  const [sources,  setSources]  = useState([])

  // ── Review state ──────────────────────────────────────────────────────────
  const [loading,  setLoading]  = useState(false)
  const [stepIdx,  setStepIdx]  = useState(-1)
  const [error,    setError]    = useState('')
  const [result,   setResult]   = useState(null)
  const [findings, setFindings] = useState([])
  const [filtered, setFiltered] = useState([])
  const [activeFilter, setActiveFilter] = useState('all')
  const [reviewedBlob, setReviewedBlob] = useState(null)
  const [outName,  setOutName]  = useState('reviewed.docx')
  const [reviewId, setReviewId] = useState('')
  const [dispositions, setDispositions] = useState({})

  // ── History ───────────────────────────────────────────────────────────────
  const [history,  setHistory]  = useState([])

  // ── Init ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    const savedKey = sessionStorage.getItem(LS_KEYS.apiKey)
    if (savedKey) { setApiKey(savedKey); setKeyOk(true) }
    const savedCfg = loadLS(LS_KEYS.config, { author: '', initials: '', org: '' })
    setCfg(savedCfg)
    setSources(loadLS(LS_KEYS.sources, []))
    setHistory(loadLS(LS_KEYS.history, []))
    setReviewId(generateReviewId())
    setMetadata((m) => ({ ...m, date: new Date().toISOString().split('T')[0] }))
  }, [])

  // ── API Key ───────────────────────────────────────────────────────────────
  const saveKey = useCallback((k) => {
    if (!k || k.length < 20) { setError("Invalid API key — please check and try again."); return }
    setApiKey(k); sessionStorage.setItem(LS_KEYS.apiKey, k); setKeyOk(true); setError('')
  }, [])

  const changeKey = useCallback(() => {
    setApiKey(''); sessionStorage.removeItem(LS_KEYS.apiKey); setKeyOk(false)
  }, [])

  // ── Settings ──────────────────────────────────────────────────────────────
  const saveSettings = useCallback((newCfg, newKey) => {
    setCfg(newCfg)
    localStorage.setItem(LS_KEYS.config, JSON.stringify(newCfg))
    if (newKey && newKey.length >= 20) {
      setApiKey(newKey); sessionStorage.setItem(LS_KEYS.apiKey, newKey); setKeyOk(true)
    }
    setMetadata((m) => ({ ...m, company: newCfg.org || m.company }))
  }, [])

  // ── Sources ───────────────────────────────────────────────────────────────
  const saveSources = useCallback((next) => {
    setSources(next); localStorage.setItem(LS_KEYS.sources, JSON.stringify(next))
  }, [])

  const addSource = useCallback(async (file, name) => {
    const text = await readFileText(file)
    if (!text.trim()) throw new Error('No text found in file.')
    const id = 's' + Date.now() + Math.random().toString(36).slice(2, 5)
    saveSources([...sources, {
      id, name: name || file.name, fileName: file.name,
      type: file.name.split('.').pop().toUpperCase(),
      addedAt: new Date().toISOString(), active: true,
      words: text.split(/\s+/).filter(Boolean).length, text,
    }])
  }, [sources, saveSources])

  const toggleSource = useCallback((id, active) => {
    saveSources(sources.map((s) => s.id === id ? { ...s, active } : s))
  }, [sources, saveSources])

  const deleteSource = useCallback((id) => {
    saveSources(sources.filter((s) => s.id !== id))
  }, [sources, saveSources])

  // ── Main file ─────────────────────────────────────────────────────────────
  const setFile = useCallback((file) => {
    setMainFile(file); setError('')
    mainDocxBufRef.current = null
  }, [])

  const removeFile = useCallback(() => {
    setMainFile(null); mainDocxBufRef.current = null
  }, [])

  // ── Segments ──────────────────────────────────────────────────────────────
  const setSegment = useCallback((group, value) => {
    setSel((prev) => ({ ...prev, [group]: value }))
  }, [])

  // ── Review ────────────────────────────────────────────────────────────────
  const startReview = useCallback(async () => {
    if (!mainFile || !apiKey) return
    setLoading(true); setError(''); setResult(null); setFindings([]); setFiltered([])
    setDispositions({}); setReviewedBlob(null); setStepIdx(0)

    try {
      setStepIdx(0) // parse
      const mainText = await readFileText(mainFile)
      if (!mainText.trim()) throw new Error('No readable text found in document.')
      if (mainFile.name.toLowerCase().endsWith('.docx')) {
        mainDocxBufRef.current = await mainFile.arrayBuffer()
      }

      setStepIdx(1) // load
      const activeSrcs = sources.filter((s) => s.active && s.text)

      setStepIdx(2) // send
      const aiResult = await callAI({
        mainText, mainName: mainFile.name, sources: activeSrcs,
        config: { apiKey, author: cfg.author },
        sel, metadata,
      })

      setStepIdx(3) // analyze
      const allFindings = aiResult.findings || []

      setStepIdx(4) // inject
      let blob = null
      if (mainDocxBufRef.current) {
        try {
          blob = await injectComments(
            mainDocxBufRef.current, allFindings,
            cfg.author || 'QA Reviewer', cfg.initials || 'QR'
          )
        } catch (e) { console.warn('Comment injection:', e) }
      }

      setStepIdx(5) // finalize
      await new Promise((r) => setTimeout(r, 400))

      setResult(aiResult)
      setFindings(allFindings)
      setFiltered(allFindings)
      setReviewedBlob(blob)
      setOutName(mainFile.name.replace(/\.docx$/i, '') + '_reviewed.docx')

      // Save history
      const entry = {
        id: reviewId, date: new Date().toISOString(),
        docName: mainFile.name, docProject: metadata.doc,
        findingCount: allFindings.length,
        risk: aiResult.overallRisk, readiness: aiResult.auditReadiness,
      }
      const newHist = [entry, ...history].slice(0, 20)
      setHistory(newHist)
      localStorage.setItem(LS_KEYS.history, JSON.stringify(newHist))

    } catch (err) {
      setError(err.message || 'Analysis failed. Please try again.')
    } finally {
      setLoading(false); setStepIdx(-1)
    }
  }, [mainFile, apiKey, sources, cfg, sel, metadata, reviewId, history])

  // ── Filter ────────────────────────────────────────────────────────────────
  const applyFilter = useCallback((flt) => {
    setActiveFilter(flt)
    setFiltered(flt === 'all' ? findings : findings.filter((f) => f.severity === flt || f.type === flt))
  }, [findings])

  // ── Disposition ───────────────────────────────────────────────────────────
  const setDisposition = useCallback((fid, status) => {
    setDispositions((prev) => ({
      ...prev,
      [fid]: { ...prev[fid], status: prev[fid]?.status === status ? null : status },
    }))
  }, [])

  const setNote = useCallback((fid, note) => {
    setDispositions((prev) => ({ ...prev, [fid]: { ...prev[fid], note } }))
  }, [])

  // ── Reset ─────────────────────────────────────────────────────────────────
  const resetReview = useCallback(() => {
    setMainFile(null); mainDocxBufRef.current = null
    setResult(null); setFindings([]); setFiltered([])
    setDispositions({}); setReviewedBlob(null)
    setError(''); setReviewId(generateReviewId())
  }, [])

  const canStart = !!(mainFile && apiKey)

  return {
    // config
    apiKey, keyOk, cfg, sel, metadata,
    saveKey, changeKey, saveSettings, setSegment,
    setMetadata,
    // sources
    sources, addSource, toggleSource, deleteSource,
    // file
    mainFile, setFile, removeFile,
    // review
    loading, stepIdx, error, canStart, startReview,
    // results
    result, findings, filtered, activeFilter, applyFilter,
    reviewedBlob, outName, reviewId, dispositions,
    setDisposition, setNote, resetReview,
    // history
    history,
  }
}
