'use client'

// ── Settings ──────────────────────────────────────────────────────────────────
export function SettingsModal({ cfg, onClose, onSave }) {
  const s = (e) => e.stopPropagation()
  let localCfg = { ...cfg }
  let newKey = ''

  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={s}>
        <div className="modal-h">
          <span className="modal-t">Settings</span>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-b">
          <div>
            <label className="m-lbl">Reviewer Name</label>
            <input className="m-inp" defaultValue={cfg.author}
              onChange={(e) => { localCfg.author = e.target.value }} placeholder="Full Name" />
          </div>
          <div>
            <label className="m-lbl">Initials</label>
            <input className="m-inp" defaultValue={cfg.initials} maxLength={4}
              onChange={(e) => { localCfg.initials = e.target.value.toUpperCase() }}
              placeholder="JS" style={{ width: 72 }} />
          </div>
          <div>
            <label className="m-lbl">Organization</label>
            <input className="m-inp" defaultValue={cfg.org}
              onChange={(e) => { localCfg.org = e.target.value }} placeholder="MedTech Inc." />
          </div>
          <div>
            <label className="m-lbl">AI Engine API Key</label>
            <input className="m-inp" type="password"
              onChange={(e) => { newKey = e.target.value }}
              placeholder="Enter API key…"
              style={{ fontFamily: "'DM Mono', monospace" }} />
          </div>
          <button className="m-btn" onClick={() => { onSave(localCfg, newKey); onClose() }}>
            Save Settings
          </button>
        </div>
      </div>
    </div>
  )
}

// ── History ───────────────────────────────────────────────────────────────────
export function HistoryModal({ history, onClose }) {
  const s = (e) => e.stopPropagation()
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={s}>
        <div className="modal-h">
          <span className="modal-t">Review History</span>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-b" style={{ maxHeight: 360, overflowY: 'auto' }}>
          {!history.length ? (
            <div style={{ fontSize: 12, color: 'var(--mist2)', textAlign: 'center', padding: 20 }}>
              No review history yet.
            </div>
          ) : history.map((h) => (
            <div key={h.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--fog)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
                <span style={{ fontSize: 11, fontWeight: 600, fontFamily: "'DM Mono', monospace", color: 'var(--ink3)' }}>
                  {h.id}
                </span>
                <span style={{ fontSize: 10, color: 'var(--mist2)' }}>
                  {new Date(h.date).toLocaleString('en-GB')}
                </span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink2)', marginBottom: 2 }}>
                {h.docProject || h.docName || '—'}
              </div>
              <div style={{ display: 'flex', gap: 8, fontSize: 10, color: 'var(--mist2)' }}>
                <span>{h.findingCount} findings</span>
                <span>Risk: {h.risk || '—'}</span>
                <span>{h.readiness || '—'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ── Report ────────────────────────────────────────────────────────────────────
export function ReportModal({ reportText, onClose, onPrint, onCSV }) {
  const s = (e) => e.stopPropagation()
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal modal-wide" onClick={s}>
        <div className="modal-h">
          <span className="modal-t">Export QA Review Report</span>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-b">
          <div className="report-preview">{reportText}</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="m-btn" onClick={onPrint}>🖨 Print / PDF</button>
            <button className="m-btn" style={{ background: 'var(--emerald)' }} onClick={onCSV}>
              📊 Export CSV
            </button>
            <button className="m-btn" style={{ background: 'var(--ink3)' }} onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
