'use client'

import { useState, useRef } from 'react'

export default function SourceModal({ onClose, onAdd }) {
  const [name, setName]   = useState('')
  const [file, setFile]   = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const inputRef = useRef()

  const handleFile = (f) => {
    setFile(f)
    if (!name) setName(f.name.replace(/\.[^.]+$/, ''))
  }

  const handleAdd = async () => {
    if (!file) return
    setLoading(true); setError('')
    try {
      await onAdd(file, name)
      onClose()
    } catch (e) {
      setError('⚠ ' + e.message)
      setLoading(false)
    }
  }

  const stopProp = (e) => e.stopPropagation()

  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={stopProp}>
        <div className="modal-h">
          <span className="modal-t">Add Source Document</span>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-b">
          <div>
            <label className="m-lbl">Source Name</label>
            <input
              className="m-inp"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. ISO 11607-1:2019 / Company SOP-001"
            />
          </div>

          <div
            className={`m-dz${file ? ' has' : ''}`}
            onClick={() => inputRef.current?.click()}
          >
            {file ? (
              <>
                <div style={{ fontSize: 18, marginBottom: 5 }}>✅</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--emerald)' }}>
                  {file.name}
                </div>
              </>
            ) : (
              <>
                <div style={{ fontSize: 20, marginBottom: 6 }}>📤</div>
                <div style={{ fontSize: 12, color: 'var(--mist)' }}>Select file</div>
                <div style={{ fontSize: 10, color: 'var(--mist2)', marginTop: 3 }}>.pdf · .docx · .txt</div>
              </>
            )}
          </div>

          <input
            ref={inputRef}
            type="file"
            accept=".pdf,.docx,.txt"
            style={{ display: 'none' }}
            onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
          />

          <button className="m-btn" onClick={handleAdd} disabled={!file || loading}>
            {loading ? 'Adding…' : 'Add to Library'}
          </button>

          {error && <div className="m-err">{error}</div>}
        </div>
      </div>
    </div>
  )
}
