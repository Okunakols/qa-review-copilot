'use client'

import { fmtDate } from '@/lib/utils'

export default function Sidebar({ sources, onAdd, onToggle, onDelete }) {
  return (
    <div className="sidebar">
      <div className="sb-head">
        <span className="sb-title">Source Library</span>
        <button className="sb-add" onClick={onAdd}>+ Add</button>
      </div>

      <div className="src-scroll">
        {sources.length === 0 ? (
          <div className="src-empty">
            <span className="src-empty-icon">📚</span>
            No sources yet.<br />
            Add reference documents like<br />
            URS, SOPs, CFRs, or ISO standards.
          </div>
        ) : (
          sources.map((s) => (
            <div className="src-item" key={s.id}>
              <input
                type="checkbox"
                className="src-cb"
                checked={!!s.active}
                onChange={(e) => onToggle(s.id, e.target.checked)}
              />
              <div className="src-info">
                <div className="src-name" title={s.name}>{s.name}</div>
                <div className="src-meta">
                  {s.type} · {(s.words || 0).toLocaleString()} words · {fmtDate(s.addedAt)}
                </div>
              </div>
              <button
                className="src-del"
                onClick={() => onDelete(s.id)}
                title="Remove"
              >
                ×
              </button>
            </div>
          ))
        )}
      </div>

      <button className="add-src-btn" onClick={onAdd}>
        <span>＋</span> Add Source Document
      </button>

      <div className="sb-hint">
        Checked sources are used in the review.<br />
        Add once, reuse every time.
      </div>
    </div>
  )
}
