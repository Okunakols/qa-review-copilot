'use client'

import { useState } from 'react'
import { SIC, SBC, SCC } from '@/lib/constants'
import { copyToClipboard } from '@/lib/utils'

const FILTERS = [
  { label: 'All', value: 'all' },
  { label: '🔴 Critical', value: 'Critical' },
  { label: '🟠 Major', value: 'Major' },
  { label: '🟡 Minor', value: 'Minor' },
  { label: '🔵 Obs.', value: 'OBSERVATION' },
  { label: '🟢 OFI', value: 'OFI' },
  { label: 'Logic', value: 'LOGIC' },
  { label: 'QA Gap', value: 'QA_GAP' },
  { label: 'Trace', value: 'TRACEABILITY' },
]

export default function FindingsPanel({
  findings, filtered, activeFilter, onFilter,
  dispositions, onDisposition, onNote,
  hasResults, onReset,
}) {
  const [openIdx, setOpenIdx] = useState(null)

  const toggle = (i) => setOpenIdx(openIdx === i ? null : i)

  return (
    <div className="panel-r">
      <div className="pr-head">
        <span className="pr-title">Findings</span>
        <span className="pr-count">
          {hasResults ? `${findings.length} findings` : '—'}
        </span>
      </div>

      {hasResults && (
        <div className="filter-wrap">
          <div className="filter-chips">
            {FILTERS.map((f) => (
              <button
                key={f.value}
                className={`chip${activeFilter === f.value ? ' on' : ''}`}
                onClick={() => onFilter(f.value)}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="findings-list">
        {!hasResults ? (
          <div className="fc-empty">
            <div className="fc-empty-icon">🔎</div>
            <p>
              Start a review to see findings here.<br />
              Each finding includes source evidence,<br />
              regulatory reference, and Word comment.
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '30px', fontSize: '12px', color: 'var(--mist2)' }}>
            No findings for this filter.
          </div>
        ) : (
          filtered.map((f, i) => (
            <FindingCard
              key={f.id}
              finding={f}
              isOpen={openIdx === i}
              onToggle={() => toggle(i)}
              disposition={dispositions[f.id] || {}}
              onDisposition={(status) => onDisposition(f.id, status)}
              onNote={(note) => onNote(f.id, note)}
            />
          ))
        )}
      </div>

      {hasResults && (
        <div style={{ padding: '10px', borderTop: '1px solid var(--fog)', flexShrink: 0 }}>
          <button className="new-btn" style={{ width: '100%' }} onClick={onReset}>
            ↺ New Review
          </button>
        </div>
      )}
    </div>
  )
}

function FindingCard({ finding: f, isOpen, onToggle, disposition, onDisposition, onNote }) {
  const [copying, setCopying] = useState({})

  const copy = async (key, text) => {
    await copyToClipboard(text)
    setCopying((p) => ({ ...p, [key]: true }))
    setTimeout(() => setCopying((p) => ({ ...p, [key]: false })), 2000)
  }

  const badNoSource = !f.sourceEvidence ||
    f.sourceEvidence.includes('not found') ||
    f.sourceEvidence.includes('bulunamad')

  return (
    <div className={`fc ${SCC[f.severity] || 'sI'}`}>
      <div className="fc-hdr" onClick={onToggle}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="fc-badges">
            <span className={`sb ${SBC[f.severity] || 'sbI'}`}>
              {SIC[f.severity] || '•'} {f.severity}
            </span>
            <span className="sb sb-type">{f.type}</span>
          </div>
          <div className="fc-title">{f.issue || 'Finding'}</div>
          {f.regulatoryRef && (
            <div style={{ marginTop: 4 }}>
              <span className="reg-pill">{f.regulatoryRef}</span>
            </div>
          )}
        </div>
        <div className={`fc-chevron${isOpen ? ' open' : ''}`}>▾</div>
      </div>

      {isOpen && (
        <div className="fc-body open">
          {!badNoSource && (
            <div className="fp">
              <div className="fp-lbl" style={{ color: 'var(--teal)' }}>
                📖 Source Evidence{f.sourceRef ? ` — ${f.sourceRef}` : ''}
              </div>
              <div className="ev-block">{f.sourceEvidence}</div>
            </div>
          )}

          <div className="fp">
            <div className="fp-lbl">⚠ Issue</div>
            <div className="fp-val">{f.issue || '—'}</div>
          </div>

          {f.whyItMatters && (
            <div className="fp">
              <div className="fp-lbl">⚖ Regulatory Impact</div>
              <div className="fp-val" style={{ fontStyle: 'italic', color: 'var(--mist)' }}>
                {f.whyItMatters}
              </div>
            </div>
          )}

          <div className="fp" style={{ background: 'rgba(26,86,219,.03)' }}>
            <div className="fp-lbl" style={{ color: 'var(--brand)' }}>
              💬 Word Comment
              <button
                className={`cpy${copying.comment ? ' ok' : ''}`}
                onClick={() => copy('comment', f.comment || '')}
              >
                {copying.comment ? '✓' : 'Copy'}
              </button>
            </div>
            <div className="cmnt-block">&ldquo;{f.comment || '—'}&rdquo;</div>
          </div>

          {f.suggestedFix && (
            <div className="fp">
              <div className="fp-lbl" style={{ color: 'var(--emerald)' }}>🔧 Suggested Fix</div>
              <div className="fix-block">{f.suggestedFix}</div>
            </div>
          )}

          {f.correctedText && (
            <div className="fp">
              <div className="fp-lbl" style={{ color: 'var(--violet)' }}>
                ✏ Corrected Text
                <button
                  className={`cpy${copying.corrected ? ' ok' : ''}`}
                  onClick={() => copy('corrected', f.correctedText)}
                >
                  {copying.corrected ? '✓' : 'Copy'}
                </button>
              </div>
              <div className="code-block">{f.correctedText}</div>
            </div>
          )}

          {f.trackChange?.type && f.trackChange.type !== 'none' && f.trackChange.originalText && (
            <div className="fp">
              <div className="fp-lbl" style={{ color: 'var(--teal)' }}>🔄 Track Change</div>
              <div className="fp-val">
                <span className="tc-del">{f.trackChange.originalText}</span>
                <span className="tc-ins">→ {f.trackChange.suggestedText}</span>
              </div>
            </div>
          )}

          <div className="fp" style={{ background: 'var(--fog3)' }}>
            <div className="fp-lbl">Disposition</div>
            <div className="disp-row">
              {['accepted', 'rejected', 'deferred'].map((s) => (
                <button
                  key={s}
                  className={`disp-btn disp-${s === 'accepted' ? 'accept' : s === 'rejected' ? 'reject' : 'defer'}${disposition.status === s ? ' sel' : ''}`}
                  onClick={() => onDisposition(s)}
                >
                  {s === 'accepted' ? '✓ Accept' : s === 'rejected' ? '✗ Reject' : '⊙ Defer'}
                </button>
              ))}
              <input
                className="disp-note"
                placeholder="Add reviewer note…"
                defaultValue={disposition.note || ''}
                onBlur={(e) => onNote(e.target.value)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
